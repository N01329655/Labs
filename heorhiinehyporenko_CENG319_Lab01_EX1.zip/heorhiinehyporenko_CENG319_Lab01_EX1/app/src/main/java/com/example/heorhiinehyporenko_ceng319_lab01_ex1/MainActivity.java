package com.example.heorhiinehyporenko_ceng319_lab01_ex1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    // declaration***
        bottom_fragment b_f = new bottom_fragment();
        TextView tex1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tex1 = (TextView) findViewById(R.id.bottm_text);
        b_f.display(getString(R.string.onC),tex1);
    }
    protected void onStart(){
        super.onStart();
        b_f.display(getString(R.string.onS),tex1);

    }
}